//search button
//search goes to controller
$("#searchsubmit").on("click", function(e) {
  //prevent the default action

 e.preventDefault();

//setting the data and the identifier
 var data = {
        searchterm : $('#searchbox').val(),


      isearch4u: "do it"
    };

//ajax post request with promise handler
    $.ajax({
         type: 'POST',
         url: "projcontroller.php",
         data: data, 
         success: function(response) {
            alert(response);
            //console.log(response);
             
         },
        error: function() {
            alert("There was an error searching");
        }
     });
           

});