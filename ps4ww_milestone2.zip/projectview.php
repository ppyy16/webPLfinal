<?php
//project view
require_once('projectmodel.php');

//session checker otherwise dont let them here
if(!isset($_SESSION['loggedin'])) {
    header('Location:index5.html');
}


class projectview {
	//variable model
	private $model;

	//view constructor for building new instance of model
	function __construct() {
		$this->model = new projectmodel();
	}

	//run function view student info and encode it into json to send back
	public function addartist() {
		$result = $this->model->addartist();

        // result will hold an associate array of students
		echo json_encode($result);
	}


	
	public function searchartist($artiststagename) {
		$result = $this->model->searchartist($artiststagename);
		echo json_encode($result);
	}



	
}

?>
