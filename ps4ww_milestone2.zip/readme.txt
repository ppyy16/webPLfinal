uvaid: ps4ww

Project Milestone

index5.html -> the main page

projcontroller.php -> controller

projectview.php -> view

projectmodel.php -> model

userpage.php -> user page (dynamic)

createDB.php -> database creator

references.txt -> references

addartist.php -> add artist page

addartist.js -> add artist functionality JS

javascriptneeds.js  -> other JS needs go in this

logout.php  -> logout page



>>ignore userpage.html<<


requires sampleuser.jpg




1. Approximately how long did this assignment take you?

I've been working on this for 3 days from when we get out of class until around 12 PM ever since Monday.
So I'd say 27 hours or something similar. The problem is a lot of careless mistakes which become bugs down the line with so many things to manage at once which keep me on one function for hours.


2. Was there a particular aspect of this assignment you found challenging?

I have a lot of trouble debugging. I cannot figure out what the easiest way is to debug all these different languages. After doing the last assignment I have a pretty good idea of where things go in the MVC but because there is so much going on I have trouble keeping everything together as well. I also think it is really challenging to learn and apply everything I learned in such a short amount of time. It hasn't really had time to absorb or sink in well enough for me to do such a big project.

3. Did you complete the work required by your milestone? If not, what kept you from completing this?

I did finish the back-end almost entirely(because I switched my front and back end). I think what is really challenging about my project is that there are so many different aspects to it that it is a lot of work for someone who is a beginner in web development. It's too big of a bite to chew.

4. Are there any changes to your project?
Yes, I don't think I will be allowing users to edit their profiles because I do not believe I have time to add that functionality by the end of the project. I also think it will be a better idea to embed comments on peoples page and allow only them to (twitter style) post comments and recommend music etc. I think the comment section is a work in progress and I will not be adding it in until much later as my 3rd party library.

5. What remaining steps do you have?
I have to make the front end of the artist pages and allow people to add the artist to their page. Then I have to embed the comment section to each users profile. There is also some error catching that I have to take care of throughout the code. I also need to dynamically change the user profile pictures which I haven't gotten to yet.